﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DriverInformation.Model;
using System.Net.Http.Headers;

namespace DriverInformation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriversController : ControllerBase
    {
        private readonly DriverDbContext _context;
        private IWebHostEnvironment _webHostEnvironment;

        public DriversController(DriverDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment ?? throw new ArgumentNullException(nameof(webHostEnvironment));
            
        }

        // GET: api/Drivers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Driver>>> GetDrivers()
        {
          if (_context.Drivers == null)
          {
              return NotFound();
          }
            return await _context.Drivers.ToListAsync();
        }

        // GET: api/Drivers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Driver>> GetDriver(int id)
        {
          if (_context.Drivers == null)
          {
              return NotFound();
          }
            var driver = await _context.Drivers.FindAsync(id);

            if (driver == null)
            {
                return NotFound();
            }

            return driver;
        }

        // PUT: api/Drivers/5
        
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDriver([FromForm] int id, Driver driver)
        {
            if (id != driver.Id)
            {
                return BadRequest();
            }

            _context.Entry(driver).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DriverExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        [HttpPost]
        public async Task<ActionResult<Driver>> PostDriver([FromForm] Driver driver)
        {
            if (driver.Image != null && driver.Image.Length > 0)
            {
                var folderName = "Files";

                if (_webHostEnvironment.WebRootPath != null && folderName != null)
                {
                    var filePath = Path.Combine(_webHostEnvironment.WebRootPath, folderName);

                    if (!Directory.Exists(filePath))
                        Directory.CreateDirectory(filePath);

                    var fileName = Guid.NewGuid().ToString() + "_" + driver.Image.FileName;
                    var fileFullPath = Path.Combine(filePath, fileName);

                    using (var stream = new FileStream(fileFullPath, FileMode.Create))
                    {
                        await driver.Image.CopyToAsync(stream);
                    }

                    driver.ImageUrl = $"/{folderName}/{fileName}";
                }
                else
                {
                   
                    return BadRequest("WebRootPath or folderName is null");
                }
            }

            _context.Drivers.Add(driver);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDriver", new { id = driver.Id }, driver);
        }






        // DELETE: api/Drivers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDriver(int id)
        {
            if (_context.Drivers == null)
            {
                return NotFound();
            }
            var driver = await _context.Drivers.FindAsync(id);
            if (driver == null)
            {
                return NotFound();
            }

            _context.Drivers.Remove(driver);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DriverExists(int id)
        {
            return (_context.Drivers?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
