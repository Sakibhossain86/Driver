﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using System.Diagnostics;

namespace DriverInformation.Model
{
    public class DriverDbContext : DbContext
    {
        public DriverDbContext(DbContextOptions<DriverDbContext> options) : base(options)
        {
        }

        public DbSet<Driver> Drivers { get; set; }
       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Driver>()
            //.HasMany(user => user.Posts)
            //.WithOne(post => post.User)
            //.HasForeignKey(post => post.UserId);


        }

    }
}
