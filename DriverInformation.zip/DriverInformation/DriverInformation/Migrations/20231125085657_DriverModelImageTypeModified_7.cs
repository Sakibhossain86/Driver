﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DriverInformation.Migrations
{
    /// <inheritdoc />
    public partial class DriverModelImageTypeModified_7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
