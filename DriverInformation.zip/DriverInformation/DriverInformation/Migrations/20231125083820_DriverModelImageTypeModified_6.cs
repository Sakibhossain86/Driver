﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DriverInformation.Migrations
{
    /// <inheritdoc />
    public partial class DriverModelImageTypeModified_6 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Image",
                table: "Drivers");

            migrationBuilder.AddColumn<string>(
                name: "ImageUrl",
                table: "Drivers",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ImageUrl",
                table: "Drivers");

            migrationBuilder.AddColumn<byte[]>(
                name: "Image",
                table: "Drivers",
                type: "varbinary(max)",
                nullable: true);
        }
    }
}
