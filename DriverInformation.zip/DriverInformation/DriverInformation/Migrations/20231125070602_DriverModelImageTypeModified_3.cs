﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DriverInformation.Migrations
{
    /// <inheritdoc />
    public partial class DriverModelImageTypeModified_3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Image",
                table: "Drivers");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<byte[]>(
                name: "Image",
                table: "Drivers",
                type: "varbinary(max)",
                nullable: true);
        }
    }
}
