﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DriverInformation.Migrations
{
    /// <inheritdoc />
    public partial class DriverModelImageTypeModified_4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SystemId",
                table: "Drivers",
                newName: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Drivers",
                newName: "SystemId");
        }
    }
}
